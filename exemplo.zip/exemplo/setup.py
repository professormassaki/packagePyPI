from setuptools import setup

with open("README.md", "r") as fh:
    readme = fh.read()

setup(name='exemploMSK24',
    version='0.0.1',
    url='https://github.com/massakiigarashi2/exemploMSK24',
    license='MIT License',
    author='Massaki',
    long_description=readme,
    long_description_content_type="text/markdown",
    author_email='massaki.igarashi@gmail.com',
    keywords='package',
    description=u'Exemplo de pacote PyPI',
    packages=['exemploMSK24'],
    install_requires=['numpy'],)