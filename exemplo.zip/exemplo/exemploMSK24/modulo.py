import numpy as np

def teste():
    print(np.arange(0,10))
    print('Seu pacote PyPI esta funcionando.')