from setuptools import setup
setup(name='mypackage',
version='0.1',
description='Testing installation of Package',
url='#',
author='prof.massaki',
author_email='prof.massaki@gmail.com',
license='MIT',
packages=['mypackage'],
zip_safe=False)