from setuptools import setup

setup(
    name = 'aluratempMSK3',
    version = '0.3',
    author = 'Massaki Igarashi',
    author_email = 'prof.massaki@gmail.com',
    #packages = ['aluratempMSK'],
    description = 'Um simples conversor de temperatura (Celsius - Fahrenheit)',
    long_description = 'Um simples conversor de temperatura, com funções para '
                        + 'conversão de Celsius para Fahrenheit e vice-versa, '
                        + 'usado para um post no Blog da Alura',
    #url = 'https://github.com/massakiigarashi2',
    project_urls = {
        'Código fonte': 'https://github.com/massakiigarashi2',
        'Download': 'https://github.com/massakiigarashi2'
    },
    license = 'MIT',
    keywords = 'conversor temperatura alura',
    classifiers = [
        'Development Status :: 5 - Production/Stable',
        'Intended Audience :: Developers',
        'License :: OSI Approved :: MIT License',
        'Natural Language :: Portuguese (Brazilian)',
        'Operating System :: OS Independent',
        'Topic :: Software Development :: Internationalization',
        'Topic :: Scientific/Engineering :: Physics'
    ]
)

