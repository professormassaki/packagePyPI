def soma (x, y):
    return x + y

def sub (x, y):
    return x - y

def mult (x, y):
    return x * y
    
if __name__ == '__main__':
    main()