import sys

from LibCalcMSK2 import funcoes

if __name__ == "__main__":
    main()
