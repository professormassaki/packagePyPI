#from setuptools import setup
import setuptools

setuptools.setup(
  name='LibCalcMSK3',
  version='2',
  author='Massaki Igarashi',
  author_email='prof.massaki@gmail.com',   
  #scripts=['bin/script1','bin/script2'],
  url='http://pypi.python.org/pypi/LibCalcMSK3',  
  license='LICENSE.txt',
  description='Meu primeiro package Python',
  #packages=['geopandas', 'geopandas.io', 'geopandas.tools'],
  #packages=setuptools.find_packages(),
  classifiers=["Programming Language :: Python :: 3",
              "License :: OSI Approved :: MIT License",
              "Operating System :: OS Independent"],
  install_requires=["pytest",
                    "pandas",
                    #"Django >= 1.1.1"
                    ]
)